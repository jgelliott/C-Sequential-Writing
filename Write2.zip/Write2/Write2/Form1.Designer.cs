﻿namespace Write2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtlname = new System.Windows.Forms.TextBox();
            this.txtfname = new System.Windows.Forms.TextBox();
            this.lbbranch = new System.Windows.Forms.ListBox();
            this.radfresh = new System.Windows.Forms.RadioButton();
            this.radsoph = new System.Windows.Forms.RadioButton();
            this.radjunior = new System.Windows.Forms.RadioButton();
            this.radsenior = new System.Windows.Forms.RadioButton();
            this.radgrad = new System.Windows.Forms.RadioButton();
            this.chkdiploma = new System.Windows.Forms.CheckBox();
            this.chkrecord = new System.Windows.Forms.CheckBox();
            this.chkdrugs = new System.Windows.Forms.CheckBox();
            this.chkweight = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnwrite = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtlname
            // 
            this.txtlname.Location = new System.Drawing.Point(188, 41);
            this.txtlname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtlname.Name = "txtlname";
            this.txtlname.Size = new System.Drawing.Size(240, 22);
            this.txtlname.TabIndex = 0;
            // 
            // txtfname
            // 
            this.txtfname.Location = new System.Drawing.Point(188, 107);
            this.txtfname.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(240, 22);
            this.txtfname.TabIndex = 1;
            // 
            // lbbranch
            // 
            this.lbbranch.FormattingEnabled = true;
            this.lbbranch.ItemHeight = 16;
            this.lbbranch.Items.AddRange(new object[] {
            "Army",
            "Air Force",
            "Marines",
            "Navy"});
            this.lbbranch.Location = new System.Drawing.Point(188, 170);
            this.lbbranch.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.lbbranch.Name = "lbbranch";
            this.lbbranch.Size = new System.Drawing.Size(240, 132);
            this.lbbranch.TabIndex = 2;
            // 
            // radfresh
            // 
            this.radfresh.AutoSize = true;
            this.radfresh.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radfresh.Location = new System.Drawing.Point(489, 43);
            this.radfresh.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radfresh.Name = "radfresh";
            this.radfresh.Size = new System.Drawing.Size(94, 20);
            this.radfresh.TabIndex = 3;
            this.radfresh.TabStop = true;
            this.radfresh.Text = "Freshman";
            this.radfresh.UseVisualStyleBackColor = true;
            this.radfresh.CheckedChanged += new System.EventHandler(this.radfresh_CheckedChanged);
            // 
            // radsoph
            // 
            this.radsoph.AutoSize = true;
            this.radsoph.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radsoph.Location = new System.Drawing.Point(489, 90);
            this.radsoph.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radsoph.Name = "radsoph";
            this.radsoph.Size = new System.Drawing.Size(106, 20);
            this.radsoph.TabIndex = 4;
            this.radsoph.TabStop = true;
            this.radsoph.Text = "Sophomore";
            this.radsoph.UseVisualStyleBackColor = true;
            this.radsoph.CheckedChanged += new System.EventHandler(this.radsoph_CheckedChanged);
            // 
            // radjunior
            // 
            this.radjunior.AutoSize = true;
            this.radjunior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radjunior.Location = new System.Drawing.Point(489, 137);
            this.radjunior.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radjunior.Name = "radjunior";
            this.radjunior.Size = new System.Drawing.Size(68, 20);
            this.radjunior.TabIndex = 5;
            this.radjunior.TabStop = true;
            this.radjunior.Text = "Junior";
            this.radjunior.UseVisualStyleBackColor = true;
            this.radjunior.CheckedChanged += new System.EventHandler(this.radjunior_CheckedChanged);
            // 
            // radsenior
            // 
            this.radsenior.AutoSize = true;
            this.radsenior.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radsenior.Location = new System.Drawing.Point(489, 183);
            this.radsenior.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radsenior.Name = "radsenior";
            this.radsenior.Size = new System.Drawing.Size(71, 20);
            this.radsenior.TabIndex = 6;
            this.radsenior.TabStop = true;
            this.radsenior.Text = "Senior";
            this.radsenior.UseVisualStyleBackColor = true;
            this.radsenior.CheckedChanged += new System.EventHandler(this.radsenior_CheckedChanged);
            // 
            // radgrad
            // 
            this.radgrad.AutoSize = true;
            this.radgrad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radgrad.Location = new System.Drawing.Point(489, 230);
            this.radgrad.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radgrad.Name = "radgrad";
            this.radgrad.Size = new System.Drawing.Size(99, 20);
            this.radgrad.TabIndex = 7;
            this.radgrad.TabStop = true;
            this.radgrad.Text = "Graduated";
            this.radgrad.UseVisualStyleBackColor = true;
            this.radgrad.CheckedChanged += new System.EventHandler(this.radgrad_CheckedChanged);
            // 
            // chkdiploma
            // 
            this.chkdiploma.AutoSize = true;
            this.chkdiploma.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkdiploma.Location = new System.Drawing.Point(692, 43);
            this.chkdiploma.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkdiploma.Name = "chkdiploma";
            this.chkdiploma.Size = new System.Drawing.Size(85, 20);
            this.chkdiploma.TabIndex = 8;
            this.chkdiploma.Text = "Diploma";
            this.chkdiploma.UseVisualStyleBackColor = true;
            this.chkdiploma.CheckedChanged += new System.EventHandler(this.chkdiploma_CheckedChanged);
            // 
            // chkrecord
            // 
            this.chkrecord.AutoSize = true;
            this.chkrecord.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkrecord.Location = new System.Drawing.Point(692, 90);
            this.chkrecord.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkrecord.Name = "chkrecord";
            this.chkrecord.Size = new System.Drawing.Size(138, 20);
            this.chkrecord.TabIndex = 9;
            this.chkrecord.Text = "Criminal Record";
            this.chkrecord.UseVisualStyleBackColor = true;
            this.chkrecord.CheckedChanged += new System.EventHandler(this.chkrecord_CheckedChanged);
            // 
            // chkdrugs
            // 
            this.chkdrugs.AutoSize = true;
            this.chkdrugs.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkdrugs.Location = new System.Drawing.Point(692, 137);
            this.chkdrugs.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkdrugs.Name = "chkdrugs";
            this.chkdrugs.Size = new System.Drawing.Size(157, 20);
            this.chkdrugs.TabIndex = 10;
            this.chkdrugs.Text = "Previous Drug Use";
            this.chkdrugs.UseVisualStyleBackColor = true;
            this.chkdrugs.CheckedChanged += new System.EventHandler(this.chkdrugs_CheckedChanged);
            // 
            // chkweight
            // 
            this.chkweight.AutoSize = true;
            this.chkweight.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkweight.Location = new System.Drawing.Point(692, 183);
            this.chkweight.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.chkweight.Name = "chkweight";
            this.chkweight.Size = new System.Drawing.Size(135, 20);
            this.chkweight.TabIndex = 11;
            this.chkweight.Text = "Passing Weight";
            this.chkweight.UseVisualStyleBackColor = true;
            this.chkweight.CheckedChanged += new System.EventHandler(this.chkweight_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(36, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 12;
            this.label1.Text = "Last Name";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(36, 107);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 16);
            this.label2.TabIndex = 13;
            this.label2.Text = "First Name";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(36, 170);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 34);
            this.label3.TabIndex = 14;
            this.label3.Text = "Branch of Interest";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // btnwrite
            // 
            this.btnwrite.Location = new System.Drawing.Point(144, 383);
            this.btnwrite.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnwrite.Name = "btnwrite";
            this.btnwrite.Size = new System.Drawing.Size(225, 119);
            this.btnwrite.TabIndex = 15;
            this.btnwrite.Text = "Write";
            this.btnwrite.UseVisualStyleBackColor = true;
            this.btnwrite.Click += new System.EventHandler(this.btnwrite_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(502, 383);
            this.btnExit.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(225, 119);
            this.btnExit.TabIndex = 16;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(889, 598);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnwrite);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.chkweight);
            this.Controls.Add(this.chkdrugs);
            this.Controls.Add(this.chkrecord);
            this.Controls.Add(this.chkdiploma);
            this.Controls.Add(this.radgrad);
            this.Controls.Add(this.radsenior);
            this.Controls.Add(this.radjunior);
            this.Controls.Add(this.radsoph);
            this.Controls.Add(this.radfresh);
            this.Controls.Add(this.lbbranch);
            this.Controls.Add(this.txtfname);
            this.Controls.Add(this.txtlname);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtlname;
        private System.Windows.Forms.TextBox txtfname;
        private System.Windows.Forms.ListBox lbbranch;
        private System.Windows.Forms.RadioButton radfresh;
        private System.Windows.Forms.RadioButton radsoph;
        private System.Windows.Forms.RadioButton radjunior;
        private System.Windows.Forms.RadioButton radsenior;
        private System.Windows.Forms.RadioButton radgrad;
        private System.Windows.Forms.CheckBox chkdiploma;
        private System.Windows.Forms.CheckBox chkrecord;
        private System.Windows.Forms.CheckBox chkdrugs;
        private System.Windows.Forms.CheckBox chkweight;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnwrite;
        private System.Windows.Forms.Button btnExit;
    }
}

